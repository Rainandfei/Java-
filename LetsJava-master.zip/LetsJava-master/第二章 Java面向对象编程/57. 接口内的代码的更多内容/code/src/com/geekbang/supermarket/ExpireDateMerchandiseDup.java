package com.geekbang.supermarket;

// >> TODO 和抽象方法不同，如果一个类实现了两个接口，并且两个接口里有相同的缺省方法，编译器会报错
public interface ExpireDateMerchandiseDup {
//
//   default void testDuplicatedMethod(){
//
//   }
//
}
