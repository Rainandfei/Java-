package com.geekbang.person;

public class Customer {
    public String name;
    public double money;
    public boolean isDrivingCar;
}
