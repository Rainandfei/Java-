package com.geekbang.inner;

public class Outter {
}
