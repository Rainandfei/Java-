package com.geekbang.anonymous;

public interface Intf {
}
