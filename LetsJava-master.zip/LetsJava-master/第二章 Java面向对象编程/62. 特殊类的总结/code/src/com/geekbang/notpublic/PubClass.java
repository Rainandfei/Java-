package com.geekbang.notpublic;

public class PubClass {
}
