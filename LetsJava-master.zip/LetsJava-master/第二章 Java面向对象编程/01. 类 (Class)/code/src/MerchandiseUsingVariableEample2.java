public class MerchandiseUsingVariableEample2 {
    public static void main(String[] args) {
        String m1Name = "茉莉花茶叶20包";
        int m1Count = 20;
    }
}
