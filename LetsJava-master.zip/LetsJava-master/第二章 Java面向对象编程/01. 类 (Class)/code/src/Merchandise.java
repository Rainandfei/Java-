
// >> TODO 一个类以public class开头，public class代表这个类是公共类，类名必须和文件名相同。
// >> TODO public class后面紧跟类名，然后是一对打括号的类体
public class Merchandise {
    // >> TODO 类体中可以定义描述这个类的属性的变量。我们称之为成员变量（member variable）
    // >> TODO 每个成员变量的定义以;结束
    String name;
    String id;
    int count;
    double price;

}

// >> TODO 上面这整个类，其实就是创建了一个模版。描述了一种我们需要的数据类型。