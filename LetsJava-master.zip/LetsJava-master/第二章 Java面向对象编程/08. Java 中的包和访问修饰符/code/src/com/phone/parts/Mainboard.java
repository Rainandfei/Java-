package com.phone.parts;

public class Mainboard {
    public CPU cpu;
    public Memory memory;
    public Storage storage;
    public String model;
    // 上市年份
    public int year;
}
