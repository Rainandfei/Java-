package com.phone.parts;

public class Memory {
    public long capacity;
    public String producer;
}
