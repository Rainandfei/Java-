
package com.phone.parts;

public class Screen {
    public double size;
    public String producer;
}
