package com.phone;

import com.phone.parts.Mainboard;
import com.phone.parts.Screen;

public class Phone {
    Screen screen;
    Mainboard mainboard;
    double price;
    boolean hasFigurePrintUnlocker;
}
