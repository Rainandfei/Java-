package com.phone.parts;

public class CPU {
    public double speed;
    public String producer;
}
