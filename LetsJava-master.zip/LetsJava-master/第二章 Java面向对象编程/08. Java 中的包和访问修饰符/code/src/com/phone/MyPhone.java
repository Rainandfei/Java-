package com.phone;

import com.phone.parts.*;

public class MyPhone {
    Memory memory;
    Storage storage;
}
