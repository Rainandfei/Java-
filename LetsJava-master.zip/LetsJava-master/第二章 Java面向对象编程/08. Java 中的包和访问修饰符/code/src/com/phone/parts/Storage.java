package com.phone.parts;

public class Storage {
    public long capacity;
    public String producer;
}
