public class Merchandise {
    String name;
    String id;
    int count;
    double price;
}
