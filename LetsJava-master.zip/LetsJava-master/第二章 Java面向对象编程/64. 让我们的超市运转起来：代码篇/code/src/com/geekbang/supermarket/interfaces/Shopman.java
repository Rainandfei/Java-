package com.geekbang.supermarket.interfaces;

public interface Shopman {

    void serveCustomer(Customer customer);

}
