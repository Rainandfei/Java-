package com.geekbang.supermarket.interfaces;

public interface HasCard {
    Card getCard();
}
