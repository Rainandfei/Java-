package com.geekbang.supermarket;

// >> TODO 接口甚至可以没有任何方法的定义，只是规定一种类型
public interface VirtualMerchandise {
}
