package com.geekbang.intf;

public interface Intf2 {
    void m1();

    void m2();

}
