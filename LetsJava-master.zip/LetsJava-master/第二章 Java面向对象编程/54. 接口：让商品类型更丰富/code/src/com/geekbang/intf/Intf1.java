package com.geekbang.intf;

public interface Intf1 {
    void m1();
}
