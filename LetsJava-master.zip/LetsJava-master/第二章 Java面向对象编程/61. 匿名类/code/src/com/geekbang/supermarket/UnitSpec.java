package com.geekbang.supermarket;

public interface UnitSpec {
    double getNumSpec();

    String getProducer();
}
