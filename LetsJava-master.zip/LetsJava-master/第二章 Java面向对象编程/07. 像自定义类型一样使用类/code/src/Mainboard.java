public class Mainboard {
    CPU cpu;
    Memory memory;
    Storage storage;
    String model;
    // 上市年份
    int year;
}
