public class Storage {
    long capacity;
    String producer;
}
