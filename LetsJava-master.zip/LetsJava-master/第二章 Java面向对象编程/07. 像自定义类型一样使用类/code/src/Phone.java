public class Phone {
    Screen screen;
    Mainboard mainboard;
    double price;
    boolean hasFigurePrintUnlocker;

    Phone prePhone;
}
