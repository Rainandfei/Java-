public class CPU {
    double speed;
    String producer;
}
