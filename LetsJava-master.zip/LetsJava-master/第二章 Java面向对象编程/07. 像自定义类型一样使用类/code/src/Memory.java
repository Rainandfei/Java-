public class Memory {
    long capacity;
    String producer;
}
