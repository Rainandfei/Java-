public class Screen {
    double size;
    String producer;
}
