public class Example {
}
