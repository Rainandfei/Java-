public class Merchandise1 {
    String name;
    String id;
    int count;
    double price;

}
