package com.geekbang.supermarket;

// >> TODO 非public的类，类名可以不和文件名相同
class NonPublicClassCanUseAnyName {
}
