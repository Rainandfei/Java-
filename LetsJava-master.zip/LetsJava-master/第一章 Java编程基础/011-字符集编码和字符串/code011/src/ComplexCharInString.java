public class ComplexCharInString {
    public static void main(String[] args) {
        String content = "a\tb\tcc\tee\t";
        String align = "1111222233334444";
        System.out.println(content);
        System.out.println(align);
    }
}
