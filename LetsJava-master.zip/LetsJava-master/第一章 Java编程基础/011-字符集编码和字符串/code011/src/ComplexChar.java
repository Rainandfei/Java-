public class ComplexChar {
    public static void main(String[] args) {
        int a = 65;
        char cha = (char) a;

        char zang = '\u81e7';

        System.out.println(cha);

        System.out.println(zang);
    }
}
