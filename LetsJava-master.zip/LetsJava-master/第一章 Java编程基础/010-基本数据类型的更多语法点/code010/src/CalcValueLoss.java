public class CalcValueLoss {
    public static void main(String[] args) {
        int intVal = 2000000000;
        System.out.println(intVal + intVal);
    }
}
