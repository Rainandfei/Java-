public class AssignFirst {
    public static void main(String[] args) {

        int a;


    }
}
