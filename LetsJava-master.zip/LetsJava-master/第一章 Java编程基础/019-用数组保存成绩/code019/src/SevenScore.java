public class SevenScore {
    public static void main(String[] args) {
        // 声明六个变量， 分别代表六门科目的成绩
        int YuWen = 0;
        int ShuXue = 0;
        int WaiYu = 0;
        int WuLi = 0;
        int HuaXue = 0;
        int ShengWu = 0;


    }
}
