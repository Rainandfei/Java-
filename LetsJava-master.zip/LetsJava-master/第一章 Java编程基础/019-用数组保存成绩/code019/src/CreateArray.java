public class CreateArray {
    public static void main(String[] args) {
        int[] intArray = new int[9];

        System.out.println(intArray[2]);

        double[] doubleArray = new double[100];

        System.out.println(doubleArray[66]);

    }
}
