public class DoWhileExample {
    public static void main(String[] args) {

        do {
            System.out.println("会执行一次");
        } while (false);
    }
}
