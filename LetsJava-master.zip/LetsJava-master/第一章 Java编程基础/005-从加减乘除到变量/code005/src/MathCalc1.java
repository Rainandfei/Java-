public class MathCalc1 {
    public static void main(String[] args) {
        System.out.println(5 + 6);
        System.out.println(5 - 6);
        System.out.println(5 * 6);
        System.out.println(5 / 6.0);

        System.out.println(1 + 2 * 3 / 4.0 + (5 + 6) / 7.0);
    }
}
