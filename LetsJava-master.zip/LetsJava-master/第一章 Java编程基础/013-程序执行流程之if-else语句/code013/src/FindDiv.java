public class FindDiv {
    public static void main(String[] args) {
        int a = 35;
        int b = 9;

        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;
        if (a % b == 0) {
            System.out.println(a + "可以整除" + b + "。商为" + (a / b));
        }
        a++;


    }
}
