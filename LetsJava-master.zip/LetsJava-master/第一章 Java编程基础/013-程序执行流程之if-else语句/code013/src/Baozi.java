public class Baozi {
    public static void main(String[] args) {
        int baozi = 3;
        System.out.println("买了" + baozi + "个肉包子");
    }
}
