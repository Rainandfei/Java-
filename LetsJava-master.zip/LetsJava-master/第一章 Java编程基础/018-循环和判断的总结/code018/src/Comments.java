public class Comments {
    public static void main(String[] args) {
        int a = 9;//定义变量a，赋值为9
        //将a输出到控制台
        System.out.println(a);
    }
}
