public class ModCalc {
    public static void main(String[] args) {
        int num = 10;

        System.out.println(num % 2);
        System.out.println(num % -3);
        System.out.println(num % 4);
        System.out.println(num % 5);
        System.out.println(num % -6);
    }
}
