public class ParentOprt {
    public static void main(String[] args) {
        int a = 10;
        int b = 88;
        boolean c = ((a + b) * a - 9 * (a + b)) == (a + b);

        System.out.println(c);
    }
}
