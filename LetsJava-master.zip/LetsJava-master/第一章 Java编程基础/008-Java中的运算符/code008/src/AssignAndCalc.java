public class AssignAndCalc {
    public static void main(String[] args) {

        int a = 10;

        a /= 2;

        System.out.println(a);

        a += 5;

        System.out.println(a);
    }
}
