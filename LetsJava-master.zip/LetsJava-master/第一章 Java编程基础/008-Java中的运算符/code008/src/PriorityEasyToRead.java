public class PriorityEasyToRead {
    public static void main(String[] args) {
        int a = 1 + 3;
        int b = 2;

        boolean both = (a > 0) && (b > 0);
        System.out.println(both);

        boolean result = a < (b + 5);
        System.out.println(result);

    }
}
