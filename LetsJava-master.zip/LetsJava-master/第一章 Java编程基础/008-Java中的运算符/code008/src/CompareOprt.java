public class CompareOprt {
    public static void main(String[] args) {
        int a = 10;
        int b = 15;
        int c = 10;

        System.out.println(a > b);
        System.out.println(a >= b);
        System.out.println(a < b);
        System.out.println(a <= b);
        System.out.println(a != b);

        System.out.println(a != c);
        System.out.println(a >= c);
        System.out.println(a <= c);
        System.out.println(a == b);
        System.out.println(a == c);

    }
}
