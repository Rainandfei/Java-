public class Print26Chars {
    public static void main(String[] args) {
        char ch = 'A';
        int num = ch;
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));
        System.out.println(num + "\t" + ((char) num++));

    }
}
