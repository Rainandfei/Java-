package com.geekbang.exception;

public interface IntfWithEx {

    void danger() throws Exception;

    void safe();

}
